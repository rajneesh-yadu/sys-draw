/**
 * modes — public API.
 * Other modules may import ONLY from this file (enforced by eslint-plugin-boundaries).
 * See ./README.md. Implemented in S18.
 */
export {};
